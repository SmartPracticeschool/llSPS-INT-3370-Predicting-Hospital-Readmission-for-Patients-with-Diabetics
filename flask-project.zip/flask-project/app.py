import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from joblib import load

app = Flask(__name__)
model = pickle.load(open('SVC.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('hospital.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    a=request.form['insulin']
    if(a=="Down"):
        j=0
        k=0
        l=0
    elif(a=="No"):
        j=1
        k=0
        l=0
    elif(a=="steady"):
        j=0
        k=1
        l=0
    else:
        j=0
        k=0
        l=1
    
    b=request.form['rosiglitazone']
    if(b=="Down"):
        m=0
        n=0
        o=0
    elif(b=="No"):
        m=1
        n=0
        o=0
    elif(b=="steady"):
        m=0
        n=1
        o=0
    else:
        m=0
        n=0
        o=1
        
    c=request.form['pioglitazone']
    if(c=="Down"):
        p=0
        q=0
        r=0
    elif(c=="No"):
        p=1
        q=0
        r=0
    elif(c=="steady"):
        p=0
        q=1
        r=0
    else:
        p=0
        q=0
        r=1
        
    d=request.form['glyburide']
    if(d=="Down"):
        s=0
        t=0
        u=0
    elif(d=="No"):
        s=1
        t=0
        u=0
    elif(d=="steady"):
        s=0
        t=1
        u=0
    else:
        s=0
        t=0
        u=1
        
    e=request.form['glipizide']
    if(e=="Down"):
        v=0
        w=0
        x=0
    elif(e=="No"):
        v=1
        w=0
        x=0
    elif(e=="steady"):
        v=0
        w=1
        x=0
    else:
        v=0
        w=0
        x=1
        
    f=request.form['glimepiride']
    if(f=="Down"):
        y=0
        z=0
        aa=0
    elif(f=="No"):
        y=1
        z=0
        aa=0
    elif(f=="steady"):
        y=0
        z=1
        aa=0
    else:
        y=0
        z=0
        aa=1
        
    g=request.form['metformin']
    if(g=="Down"):
        bb=0
        cc=0
        dd=0
    elif(g=="No"):
        bb=1
        cc=0
        dd=0
    elif(g=="steady"):
        bb=0
        cc=1
        dd=0
    else:
        bb=0
        cc=0
        dd=1
        
    h=request.form['A1Cresult']
    if(h==">7"):
        ee=0
        ff=0
        gg=0
    elif(h==">8"):
        ee=1
        ff=0
        gg=0
    elif(h=="None"):
        ee=0
        ff=1
        gg=0
    else:
        ee=0
        ff=0
        gg=1
        
    i=request.form['max glu serum']
    if(i==">200"):
        hh=0
        ii=0
        jj=0
    elif(h==">300"):
        hh=1
        ii=0
        jj=0
    elif(h=="None"):
        hh=0
        ii=1
        jj=0
    else:
        hh=0
        ii=0
        jj=1
    x_test=[[j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,int(request.form['gender']),int(request.form['age']), int(request.form['admission type id']),int(request.form['discharge disposition id']),int(request.form['admission source id']), int(request.form['time in hospital']),int(request.form['num lab procedures']),int(request.form['num procedures']), int(request.form['num medications']),int(request.form['number diagnoses']),int(request.form['nateglinide']), int(request.form['acarbose']),int(request.form['miglitol']),int(request.form['change']),int(request.form['diabetesMed']), int(request.form['Total no of patients'])]]
    sc=load('30-day.save')
    
    prediction = model.predict(sc.transform(x_test))
    print(prediction)
    output=prediction[0]
    if(output==0):
        pred="Discharged"
    else:
        pred="Readmitted"
    return render_template('hospital.html', prediction_text=' Patient Status :{}'.format(pred))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.y_predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)
